const scholarships = [
  {
    category: "education",
    title: "Education Scholarship 1",
    description: "Description of Education Scholarship 1",
    // Include other details about the scholarship
  },
  {
    category: "education",
    title: "Education Scholarship 2",
    description: "Description of Education Scholarship 2",
    // Include other details about the scholarship
  },
  {
    category: "sports",
    title: "Sports Scholarship 1",
    description: "Description of Sports Scholarship 1",
    // Include other details about the scholarship
  },
  {
    category: "sports",
    title: "Sports Scholarship 2",
    description: "Description of Sports Scholarship 2",
    // Include other details about the scholarship
  },
  {
    category: "education",
    title: "Education Scholarship 1",
    description: "Description of Education Scholarship 1",
    // Include other details about the scholarship
  },
  {
    category: "education",
    title: "Education Scholarship 2",
    description: "Description of Education Scholarship 2",
    // Include other details about the scholarship
  },
  {
    category: "handicapped",
    title: "Handicapped Scholarship 1",
    description: "Description of Sports Scholarship 1",
    // Include other details about the scholarship
  },
  {
    category: "handicapped",
    title: "Handicapped Scholarship 2",
    description: "Description of Sports Scholarship 2",
    // Include other details about the scholarship
  },
  {
      category: "education",
      title: "Education Scholarship 1",
      description: "Description of Education Scholarship 1",
      // Include other details about the scholarship
    },
    {
      category: "Arts",
      title: " Arts&culture encouragementScholarship 2",
      description: "Description of Education Scholarship 2",
      // Include other details about the scholarship
    },
    {
      category: "Arts",
      title: "Arts",
      description: "Description of Sports Scholarship 1",
      // Include other details about the scholarship
    },
    {
      category: "sports",
      title: "Sports Scholarship 2",
      description: "Description of Sports Scholarship 2",
      // Include other details about the scholarship
    },
    {
      category: "Arts",
      title: "Arts&culture encouragement Scholarship 1",
      description: "Description of Education Scholarship 1",
      // Include other details about the scholarship
    },
    {
      category: "Arts",
      title: "Arts&culture encouragement Scholarship 2",
      description: "Description of Education Scholarship 2",
      // Include other details about the scholarship
    },
    {
      category: "sports",
      title: "Sports Scholarship 1",
      description: "Description of Sports Scholarship 1",
      // Include other details about the scholarship
    },
    {
      category: "sports",
      title: "Sports Scholarship 2",
      description: "Description of Sports Scholarship 2",
      // Include other details about the scholarship
    },
  ]

  // Add an event listener to the filtered scholarships container
const filteredScholarshipsContainer = document.querySelector('.filtered-scholarships');
filteredScholarshipsContainer.addEventListener('click', handleScholarshipClick);

// Function to handle scholarship click event
function handleScholarshipClick(event) {
  const scholarshipDiv = event.target.closest('.scholarship');
  if (scholarshipDiv) {
    scholarshipDiv.classList.toggle('pop');
  }
}


function filterScholarships() {
  const checkboxes = document.querySelectorAll('input[name="category"]:checked');
  const selectedCategories = Array.from(checkboxes).map(checkbox => checkbox.value);

  const filteredScholarshipsContainer = document.querySelector('.filtered-scholarships');
  filteredScholarshipsContainer.innerHTML = '';

  selectedCategories.forEach(category => {
    const categoryScholarships = scholarships.filter(scholarship => scholarship.category === category);

    categoryScholarships.forEach(scholarship => {
      const scholarshipDiv = document.createElement("div");
      scholarshipDiv.classList.add("scholarship");

      const titleElement = document.createElement("h3");
      titleElement.textContent = scholarship.title;

      const descriptionElement = document.createElement("p");
      descriptionElement.textContent = scholarship.description;

      scholarshipDiv.appendChild(titleElement);
      scholarshipDiv.appendChild(descriptionElement);

      filteredScholarshipsContainer.appendChild(scholarshipDiv);
    });
  });
}

function generateScholarshipPage(category) {
  const filteredScholarships = scholarships.filter((scholarship) => scholarship.category === category);

  // Convert the filtered scholarships to a JSON string
  const scholarshipData = JSON.stringify(filteredScholarships);

  // Encode the scholarship data to be passed in the URL
  const encodedData = encodeURIComponent(scholarshipData);

  // Create the URL to the new page, passing the scholarship data as a query parameter
  const url = `scholarship-page.html?data=${encodedData}`;
 

  // Redirect to the new page
  window.location.href = url;
}
