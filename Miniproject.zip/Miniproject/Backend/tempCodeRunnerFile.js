app.get("/admin",(req,res)=>{
  res.render("/admin")
})